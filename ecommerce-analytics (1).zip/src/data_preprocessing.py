# data_preprocessing.py
import os
import pandas as pd
import numpy as np

def load_data(path):
    return pd.read_csv(path, encoding="latin1", low_memory=False)

def standardize_columns(df):
    df = df.copy()
    df.columns = [c.strip().upper().replace(" ", "_").replace("/", "_") for c in df.columns]
    return df

def convert_dates(df):
    for c in df.columns:
        if "DATE" in c or "ORDER" in c:
            try:
                df[c] = pd.to_datetime(df[c], errors='coerce')
            except:
                pass
    return df

def numeric_cast(df, numeric_list=None):
    if numeric_list is None:
        numeric_list = ["SALES","QUANTITY","UNIT_PRICE","MSRP","PROFIT","DISCOUNT"]
    for c in numeric_list:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce')
    return df

def derive_fields(df):
    if "ORDERDATE" in df.columns:
        df["ORDER_YEAR"] = df["ORDERDATE"].dt.year
        df["ORDER_MONTH"] = df["ORDERDATE"].dt.to_period("M").astype(str)
    if ("SALES" in df.columns) and ("MSRP" in df.columns):
        df["PROFIT_MARGIN"] = (df["SALES"] - df["MSRP"]) / df["MSRP"]
    return df

def clean_data(df):
    df = df.drop_duplicates()
    if "SALES" in df.columns:
        df = df[df["SALES"].notna()]
    for c in df.select_dtypes(include="object").columns:
        df[c] = df[c].fillna("Unknown")
    return df

def save_clean(df, out_path):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df.to_csv(out_path, index=False)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    df = load_data(args.input)
    df = standardize_columns(df)
    df = convert_dates(df)
    df = numeric_cast(df)
    df = derive_fields(df)
    df = clean_data(df)
    save_clean(df, args.output)
    print("Saved cleaned file to", args.output)
