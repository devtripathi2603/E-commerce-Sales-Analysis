# dashboard_plotly.py
import pandas as pd
import plotly.express as px
import os

def create_html_dashboard(df, out_html="dashboard.html"):
    total_sales = df["SALES"].sum()
    total_profit = df["PROFIT"].sum() if "PROFIT" in df.columns else 0
    avg_order = df["SALES"].mean()

    df["ORDER_MONTH"] = pd.to_datetime(df["ORDERDATE"]).dt.to_period("M").astype(str)
    monthly = df.groupby("ORDER_MONTH")["SALES"].sum().reset_index()
    monthly["ORDER_MONTH"] = pd.to_datetime(monthly["ORDER_MONTH"])

    fig1 = px.line(monthly, x="ORDER_MONTH", y="SALES", title=f"Monthly Sales - Total: {total_sales:,.0f}")

    html_parts = []
    html_parts.append(f"<h1>E-commerce Sales Dashboard</h1>")
    html_parts.append(f"<p><strong>Total Sales:</strong> {total_sales:,.0f} &nbsp;&nbsp; <strong>Total Profit:</strong> {total_profit:,.0f} &nbsp;&nbsp; <strong>Avg Order:</strong> {avg_order:,.2f}</p>")
    html_parts.append(fig1.to_html(full_html=False, include_plotlyjs='cdn'))

    with open(out_html, "w") as f:
        f.write("\n".join(html_parts))
    print("Saved dashboard to", out_html)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", default="dashboard.html")
    args = parser.parse_args()
    df = pd.read_csv(args.input, parse_dates=["ORDERDATE"])
    create_html_dashboard(df, args.out)
