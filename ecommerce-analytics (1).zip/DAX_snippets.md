-- Total Sales (measure)
Total Sales = SUM('cleaned_sales_data'[SALES])

-- Total Profit
Total Profit = SUM('cleaned_sales_data'[PROFIT])

-- Average Order Value
Avg Order Value = AVERAGE('cleaned_sales_data'[SALES])

-- Sales YTD (example if ORDERDATE is a date)
Sales YTD = TOTALYTD([Total Sales], 'cleaned_sales_data'[ORDERDATE])

-- Profit Margin (measure)
Profit Margin % = DIVIDE([Total Profit], [Total Sales], 0)

-- Orders Count
Order Count = COUNTROWS('cleaned_sales_data')

-- Sales Last 12 Months (rolling)
Sales L12M = CALCULATE([Total Sales], DATESINPERIOD('cleaned_sales_data'[ORDERDATE], MAX('cleaned_sales_data'[ORDERDATE]), -12, MONTH))

-- Example calculated column: Month name
Month = FORMAT('cleaned_sales_data'[ORDERDATE], "MMM YYYY")
